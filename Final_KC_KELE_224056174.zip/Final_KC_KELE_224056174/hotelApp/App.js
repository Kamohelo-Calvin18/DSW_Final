// App.js
import React from 'react';
import { StatusBar } from 'react-native';
import RootNavigation from './src/navigation/RootNavigation';

export default function App() {
  return (
    <>
      <StatusBar barStyle="dark-content" />
      <RootNavigation />
    </>
  );
}

