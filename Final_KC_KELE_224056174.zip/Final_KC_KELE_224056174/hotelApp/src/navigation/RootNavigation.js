// src/navigation/RootNavigation.js
import React, { useState, useEffect } from 'react';
import { NavigationContainer } from '@react-navigation/native';
import AsyncStorage from '@react-native-async-storage/async-storage';

import OnboardingStack from './OnboardingStack';
import AuthStack from './AuthStack';

const RootNavigation = () => {
  const [isFirstLaunch, setIsFirstLaunch] = useState(null);

  useEffect(() => {
    AsyncStorage.getItem('alreadyLaunched').then(value => {
      if (value == null) {
        AsyncStorage.setItem('alreadyLaunched', 'true');
        setIsFirstLaunch(true);
      } else {
        setIsFirstLaunch(false);
      }
    });
  }, []);

  if (isFirstLaunch === null) return null; // splash placeholder

  return (
    <NavigationContainer>
      {isFirstLaunch ? <OnboardingStack /> : <AuthStack />}
    </NavigationContainer>
  );
};

export default RootNavigation;


