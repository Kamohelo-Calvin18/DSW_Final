// src/navigation/ExploreStack.js
import React from 'react';
import { createNativeStackNavigator } from '@react-navigation/native-stack';

import ExploreScreen from '../screens/Explore';
import HotelDetails from '../screens/HotelDetails'; // create this screen next
import Booking from '../screens/Booking';

const Stack = createNativeStackNavigator();

const ExploreStack = () => {
  return (
    <Stack.Navigator>
      <Stack.Screen name="Explore" component={ExploreScreen} options={{ headerShown: true }} />
      <Stack.Screen name="HotelDetails" component={HotelDetails} options={{ title: 'Hotel Details' }} />
      <Stack.Screen name="Booking" component={Booking} options={{ title: 'Book Hotel' }} />
    </Stack.Navigator>
  );
};

export default ExploreStack;
