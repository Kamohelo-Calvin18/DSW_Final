// src/components/ReviewItem.js
import React from 'react';
import { View, Text, StyleSheet } from 'react-native';

const ReviewItem = ({ review }) => {
  return (
    <View style={styles.container}>
      <Text style={styles.stars}>⭐ {review.rating}</Text>
      <Text style={styles.text}>{review.text}</Text>
      <Text style={styles.user}>- {review.user}</Text>
    </View>
  );
};

const styles = StyleSheet.create({
  container: {
    borderWidth: 1,
    borderColor: '#ddd',
    borderRadius: 10,
    padding: 10,
    marginBottom: 10,
    backgroundColor: '#fafafa',
  },
  stars: { fontSize: 16, fontWeight: 'bold', marginBottom: 5 },
  text: { fontSize: 14, marginBottom: 5 },
  user: { fontSize: 12, color: '#777', textAlign: 'right' },
});

export default ReviewItem;
