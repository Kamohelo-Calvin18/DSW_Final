import React from 'react';
import { View, Text, FlatList, Image, StyleSheet, TouchableOpacity } from 'react-native';

const hotels = [
  { id: '1', name: 'Sunset Resort', location: 'Cape Town, South Africa', rating: 4.5, price: 120, image: require('../../assets/hotel1.jpg') },
  { id: '2', name: 'Oceanview Hotel', location: 'Durban, South Africa', rating: 4.2, price: 100, image: require('../../assets/hotel2.jpg') },
  { id: '3', name: 'Mountain Lodge', location: 'Johannesburg, South Africa', rating: 4.8, price: 150, image: require('../../assets/hotel3.jpg') },
];

const Explore = ({ navigation }) => {
  return (
    <View style={styles.container}>
      <FlatList
        data={hotels}
        keyExtractor={(item) => item.id}
        renderItem={({ item }) => (
          <TouchableOpacity style={styles.card} onPress={() => navigation.navigate('HotelDetails', { hotel: item })}>
            <Image source={item.image} style={styles.image} />
            <View style={styles.info}>
              <Text style={styles.name}>{item.name}</Text>
              <Text style={styles.location}>{item.location}</Text>
              <Text style={styles.rating}>⭐ {item.rating}</Text>
              <Text style={styles.price}>${item.price} / night</Text>
            </View>
          </TouchableOpacity>
        )}
      />
    </View>
  );
};

const styles = StyleSheet.create({
  container: { flex: 1, padding: 10, backgroundColor: '#FFFAE5' },
  card: { marginBottom: 15, borderRadius: 12, overflow: 'hidden', backgroundColor: '#fff', elevation: 5, shadowColor: '#000', shadowOpacity: 0.2, shadowRadius: 4, shadowOffset: { width: 0, height: 3 } },
  image: { width: '100%', height: 180 },
  info: { padding: 12 },
  name: { fontSize: 18, fontWeight: 'bold', color: '#00BFFF' },
  location: { fontSize: 14, color: '#555', marginVertical: 2 },
  rating: { fontSize: 14, color: '#FFCC00' },
  price: { fontSize: 16, fontWeight: 'bold', marginTop: 5, color: '#333' },
});

export default Explore;
