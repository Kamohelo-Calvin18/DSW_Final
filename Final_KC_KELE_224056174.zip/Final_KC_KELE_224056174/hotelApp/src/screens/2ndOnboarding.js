import React from 'react';
import { View, Text, StyleSheet, Image, TouchableOpacity } from 'react-native';

const Onboarding2 = ({ navigation }) => {
  return (
    <View style={styles.container}>
      <Image source={require('../../assets/onboarding2.png')} style={styles.image} />
      <Text style={styles.title}>Book Your Room</Text>
      <Text style={styles.text}>Select dates, rooms, and make bookings easily.</Text>
      <TouchableOpacity style={styles.button} onPress={() => navigation.navigate('Onboarding3')}>
        <Text style={styles.buttonText}>Next</Text>
      </TouchableOpacity>
    </View>
  );
};

export default Onboarding2;

const styles = StyleSheet.create({
  container: {
    flex: 1,
    justifyContent: 'center',
    alignItems: 'center',
    padding: 20,
    backgroundColor: '#FFFAE5',
  },
  image: { width: 250, height: 250, marginBottom: 20 },
  title: { fontSize: 28, fontWeight: 'bold', color: '#00BFFF', marginBottom: 10 },
  text: { fontSize: 16, textAlign: 'center', marginBottom: 30, color: '#555' },
  button: { backgroundColor: '#FFCC00', padding: 15, borderRadius: 12 },
  buttonText: { color: '#fff', fontSize: 16, fontWeight: 'bold' },
});