import React, { useState } from 'react';
import { View, Text, StyleSheet, TouchableOpacity, Alert } from 'react-native';
import DateTimePicker from '@react-native-community/datetimepicker';
import { doc, updateDoc, arrayUnion } from 'firebase/firestore';
import { auth, db } from '../utils/firebase';

const Booking = ({ route, navigation }) => {
  const { hotel } = route.params;
  const today = new Date();
  const tomorrow = new Date(today);
  tomorrow.setDate(today.getDate() + 1);

  const [checkIn, setCheckIn] = useState(today);
  const [checkOut, setCheckOut] = useState(tomorrow);
  const [showCheckIn, setShowCheckIn] = useState(false);
  const [showCheckOut, setShowCheckOut] = useState(false);
  const [rooms, setRooms] = useState(1);

  const handleConfirmBooking = async () => {
    if (checkOut <= checkIn) {
      Alert.alert('Error', 'Check-out date must be after check-in date');
      return;
    }

    const days = Math.ceil((checkOut - checkIn) / (1000 * 3600 * 24));
    const totalCost = days * hotel.price * rooms;

    const booking = {
      hotelId: hotel.id,
      hotelName: hotel.name,
      checkIn: checkIn.toISOString(),
      checkOut: checkOut.toISOString(),
      rooms,
      totalCost,
    };

    try {
      const userRef = doc(db, 'users', auth.currentUser.uid);
      await updateDoc(userRef, { bookings: arrayUnion(booking) });
      Alert.alert('Booking Confirmed', `Hotel: ${hotel.name}\nCheck-in: ${checkIn.toDateString()}\nCheck-out: ${checkOut.toDateString()}\nRooms: ${rooms}\nTotal: $${totalCost}`, [
        { text: 'OK', onPress: () => navigation.goBack() },
      ]);
    } catch (error) {
      Alert.alert('Error', 'Could not save booking');
    }
  };

  return (
    <View style={styles.container}>
      <Text style={styles.title}>{hotel.name}</Text>

      <Text style={styles.label}>Select Check-in Date:</Text>
      <TouchableOpacity style={styles.dateButton} onPress={() => setShowCheckIn(true)}>
        <Text style={styles.dateText}>{checkIn.toDateString()}</Text>
      </TouchableOpacity>
      {showCheckIn && (
        <DateTimePicker
          value={checkIn}
          mode="date"
          display="default"
          minimumDate={today}
          onChange={(event, selectedDate) => {
            setShowCheckIn(false);
            if (selectedDate) setCheckIn(selectedDate);
          }}
        />
      )}

      <Text style={styles.label}>Select Check-out Date:</Text>
      <TouchableOpacity style={styles.dateButton} onPress={() => setShowCheckOut(true)}>
        <Text style={styles.dateText}>{checkOut.toDateString()}</Text>
      </TouchableOpacity>
      {showCheckOut && (
        <DateTimePicker
          value={checkOut}
          mode="date"
          display="default"
          minimumDate={checkIn}
          onChange={(event, selectedDate) => {
            setShowCheckOut(false);
            if (selectedDate) setCheckOut(selectedDate);
          }}
        />
      )}

      <Text style={styles.label}>Number of Rooms:</Text>
      <View style={styles.roomButtons}>
        <TouchableOpacity style={styles.roomBtn} onPress={() => setRooms(Math.max(1, rooms - 1))}>
          <Text style={styles.roomBtnText}>-</Text>
        </TouchableOpacity>
        <Text style={styles.roomCount}>{rooms}</Text>
        <TouchableOpacity style={styles.roomBtn} onPress={() => setRooms(rooms + 1)}>
          <Text style={styles.roomBtnText}>+</Text>
        </TouchableOpacity>
      </View>

      <TouchableOpacity style={styles.confirmButton} onPress={handleConfirmBooking}>
        <Text style={styles.confirmButtonText}>Confirm Booking</Text>
      </TouchableOpacity>
    </View>
  );
};

const styles = StyleSheet.create({
  container: { flex: 1, padding: 20, backgroundColor: '#FFFAE5' },
  title: { fontSize: 28, fontWeight: 'bold', marginBottom: 20, textAlign: 'center', color: '#00BFFF' },
  label: { fontSize: 16, marginTop: 15, marginBottom: 5, color: '#333' },
  dateButton: { backgroundColor: '#FFCC00', padding: 12, borderRadius: 10, alignItems: 'center', marginBottom: 10 },
  dateText: { color: '#fff', fontWeight: 'bold', fontSize: 16 },
  roomButtons: { flexDirection: 'row', alignItems: 'center', justifyContent: 'space-around', width: 150, marginTop: 5 },
  roomBtn: { backgroundColor: '#00BFFF', padding: 10, borderRadius: 8 },
  roomBtnText: { color: '#fff', fontWeight: 'bold', fontSize: 18 },
  roomCount: { fontSize: 18, marginHorizontal: 10 },
  confirmButton: { backgroundColor: '#FFCC00', padding: 15, borderRadius: 12, marginTop: 30 },
  confirmButtonText: { color: '#fff', fontSize: 18, fontWeight: 'bold', textAlign: 'center' },
});

export default Booking;
