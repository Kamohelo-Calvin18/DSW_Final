// src/screens/HotelDetails.js
import React, { useState } from 'react';
import { View, Text, StyleSheet, Image, ScrollView, TouchableOpacity, TextInput, Modal, FlatList } from 'react-native';

const HotelDetails = ({ route, navigation }) => {
  const { hotel } = route.params;

  // Hardcoded sample reviews
  const [reviews, setReviews] = useState([
    { id: '1', user: 'Alice', rating: 5, text: 'Amazing stay!' },
    { id: '2', user: 'Bob', rating: 4, text: 'Very comfortable rooms.' },
  ]);

  const [modalVisible, setModalVisible] = useState(false);
  const [newReviewText, setNewReviewText] = useState('');
  const [newReviewRating, setNewReviewRating] = useState('5');

  const handleAddReview = () => {
    const review = {
      id: (reviews.length + 1).toString(),
      user: 'You', // in Firebase version, replace with logged-in user's name
      rating: parseInt(newReviewRating),
      text: newReviewText,
    };
    setReviews([review, ...reviews]);
    setNewReviewText('');
    setNewReviewRating('5');
    setModalVisible(false);
  };

  return (
    <ScrollView contentContainerStyle={styles.container}>
      <Image source={hotel.image} style={styles.image} />
      <Text style={styles.name}>{hotel.name}</Text>
      <Text style={styles.location}>{hotel.location}</Text>
      <Text style={styles.rating}>⭐ {hotel.rating}</Text>
      <Text style={styles.price}>${hotel.price} per night</Text>

      <Text style={styles.description}>
        Lorem ipsum dolor sit amet, consectetur adipiscing elit. 
        Nulla et euismod nulla. Curabitur feugiat, tortor non consequat finibus, justo purus auctor massa.
      </Text>

      <TouchableOpacity
        style={styles.button}
        onPress={() => navigation.navigate('Booking', { hotel })}
      >
        <Text style={styles.buttonText}>Book Now</Text>
      </TouchableOpacity>

      {/* Reviews Section */}
      <View style={styles.reviewsContainer}>
        <Text style={styles.sectionTitle}>Reviews</Text>
        {reviews.length === 0 ? (
          <Text style={styles.placeholder}>No reviews yet. Be the first to review!</Text>
        ) : (
          <FlatList
            data={reviews}
            keyExtractor={(item) => item.id}
            renderItem={({ item }) => (
              <View style={styles.reviewItem}>
                <Text style={styles.reviewUser}>{item.user} ⭐{item.rating}</Text>
                <Text style={styles.reviewText}>{item.text}</Text>
              </View>
            )}
          />
        )}

        <TouchableOpacity style={styles.addReviewButton} onPress={() => setModalVisible(true)}>
          <Text style={styles.addReviewText}>Add Review</Text>
        </TouchableOpacity>

        {/* Add Review Modal */}
        <Modal visible={modalVisible} animationType="slide" transparent={true}>
          <View style={styles.modalContainer}>
            <View style={styles.modalContent}>
              <Text style={styles.modalTitle}>Add Review</Text>
              <TextInput
                style={styles.input}
                placeholder="Your review"
                value={newReviewText}
                onChangeText={setNewReviewText}
              />
              <TextInput
                style={styles.input}
                placeholder="Rating (1-5)"
                keyboardType="numeric"
                value={newReviewRating}
                onChangeText={setNewReviewRating}
              />
              <TouchableOpacity style={styles.button} onPress={handleAddReview}>
                <Text style={styles.buttonText}>Submit</Text>
              </TouchableOpacity>
              <TouchableOpacity style={[styles.button, { backgroundColor: '#ccc', marginTop: 10 }]} onPress={() => setModalVisible(false)}>
                <Text style={[styles.buttonText, { color: '#333' }]}>Cancel</Text>
              </TouchableOpacity>
            </View>
          </View>
        </Modal>
      </View>
    </ScrollView>
  );
};

const styles = StyleSheet.create({
  container: { padding: 20, alignItems: 'center' },
  image: { width: '100%', height: 200, borderRadius: 10, marginBottom: 20 },
  name: { fontSize: 24, fontWeight: 'bold', marginBottom: 5 },
  location: { fontSize: 16, color: '#555', marginBottom: 5 },
  rating: { fontSize: 16, color: '#f1c40f', marginBottom: 5 },
  price: { fontSize: 18, fontWeight: 'bold', marginBottom: 15 },
  description: { fontSize: 14, textAlign: 'center', marginBottom: 20 },
  button: { backgroundColor: '#4CAF50', padding: 15, borderRadius: 10, width: '100%', alignItems: 'center', marginTop: 10 },
  buttonText: { color: 'white', fontWeight: 'bold', fontSize: 16 },
  reviewsContainer: { width: '100%', marginTop: 30 },
  sectionTitle: { fontSize: 20, fontWeight: 'bold', marginBottom: 10 },
  placeholder: { fontSize: 14, color: '#555', fontStyle: 'italic', marginBottom: 10 },
  reviewItem: { borderBottomWidth: 1, borderBottomColor: '#ddd', paddingVertical: 10 },
  reviewUser: { fontWeight: 'bold' },
  reviewText: { marginTop: 2 },
  addReviewButton: { marginTop: 15, alignItems: 'center' },
  addReviewText: { color: '#4CAF50', fontWeight: 'bold', fontSize: 16 },
  modalContainer: { flex: 1, justifyContent: 'center', alignItems: 'center', backgroundColor: 'rgba(0,0,0,0.5)' },
  modalContent: { width: '85%', backgroundColor: 'white', padding: 20, borderRadius: 10 },
  modalTitle: { fontSize: 18, fontWeight: 'bold', marginBottom: 15 },
  input: { borderWidth: 1, borderColor: '#ccc', borderRadius: 5, padding: 10, marginBottom: 10 },
});

export default HotelDetails;

