import React from 'react';
import { View, Text, StyleSheet, Image, TouchableOpacity } from 'react-native';

const Onboarding3 = ({ navigation }) => {
  return (
    <View style={styles.container}>
      <Image source={require('../../assets/onboarding3.png')} style={styles.image} />
      <Text style={styles.title}>Leave Reviews</Text>
      <Text style={styles.text}>Share your experience and read reviews from other users.</Text>
      <TouchableOpacity
        style={styles.button} // fixed typo
        onPress={() => navigation.replace('SignIn')}
      >
        <Text style={styles.buttonText}>Get Started</Text>
      </TouchableOpacity>
    </View>
  );
};

export default Onboarding3;

const styles = StyleSheet.create({
  container: {
    flex: 1,
    justifyContent: 'center',
    alignItems: 'center',
    padding: 20,
    backgroundColor: '#FFFAE5',
  },
  image: { width: 250, height: 250, marginBottom: 20 },
  title: { fontSize: 28, fontWeight: 'bold', color: '#00BFFF', marginBottom: 10 },
  text: { fontSize: 16, textAlign: 'center', marginBottom: 30, color: '#555' },
  button: { backgroundColor: '#FFCC00', padding: 15, borderRadius: 12 },
  buttonText: { color: '#fff', fontSize: 16, fontWeight: 'bold' },
});

