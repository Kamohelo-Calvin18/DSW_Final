import React, { useState, useEffect } from 'react';
import { View, Text, TouchableOpacity, FlatList, StyleSheet, Alert } from 'react-native';
import { auth, db } from '../utils/firebase';
import { doc, getDoc } from 'firebase/firestore';
import { useFocusEffect } from '@react-navigation/native';


const Profile = ({ navigation }) => {
  const [user, setUser] = useState({ name: '', email: '' });
  const [bookings, setBookings] = useState([]);

  useFocusEffect(
  React.useCallback(() => {
    const fetchUser = async () => {
      if (!auth.currentUser) return;
      const userRef = doc(db, 'users', auth.currentUser.uid);
      const userSnap = await getDoc(userRef);
      if (userSnap.exists()) {
        const data = userSnap.data();
        setUser({ name: data.name, email: data.email });
        setBookings(data.bookings || []);
      }
    };
    fetchUser();
  }, [])
);


  const handleEditProfile = () => Alert.alert('Edit Profile', 'This will allow you to edit your profile (UI only)');
  const handleLogout = () => Alert.alert('Logout', 'You have been logged out', [{ text: 'OK', onPress: () => navigation.replace('SignIn') }]);

  const renderBooking = ({ item }) => (
    <View style={styles.bookingItem}>
      <Text style={styles.bookingHotel}>{item.hotelName}</Text>
      <Text style={styles.bookingDates}>
        {new Date(item.checkIn).toDateString()} → {new Date(item.checkOut).toDateString()}
      </Text>
    </View>
  );

  return (
    <View style={styles.container}>
      <Text style={styles.title}>Profile</Text>

      <View style={styles.userInfo}>
        <Text style={styles.name}>{user.name}</Text>
        <Text style={styles.email}>{user.email}</Text>
      </View>

      <TouchableOpacity style={styles.button} onPress={handleEditProfile}>
        <Text style={styles.buttonText}>Edit Profile</Text>
      </TouchableOpacity>

      <TouchableOpacity style={[styles.button, { backgroundColor: '#f44336' }]} onPress={handleLogout}>
        <Text style={styles.buttonText}>Logout</Text>
      </TouchableOpacity>

      <View style={styles.bookingsSection}>
        <Text style={styles.sectionTitle}>My Bookings</Text>
        {bookings.length === 0 ? (
          <Text style={{ color: '#555' }}>You have no bookings yet.</Text>
        ) : (
          <FlatList
            data={bookings}
            keyExtractor={(item, index) => index.toString()}
            renderItem={renderBooking}
            contentContainerStyle={{ paddingBottom: 20 }}
          />
        )}
      </View>
    </View>
  );
};

const styles = StyleSheet.create({
  container: { flex: 1, padding: 20, backgroundColor: '#FFFAE5' },
  title: { fontSize: 32, fontWeight: 'bold', marginBottom: 20, textAlign: 'center', color: '#00BFFF' },
  userInfo: { marginBottom: 20, alignItems: 'center' },
  name: { fontSize: 22, fontWeight: 'bold', color: '#333' },
  email: { fontSize: 16, color: '#555' },
  button: { backgroundColor: '#FFCC00', padding: 15, borderRadius: 12, marginBottom: 10 },
  buttonText: { color: '#fff', fontSize: 16, fontWeight: 'bold', textAlign: 'center' },
  bookingsSection: { marginTop: 20 },
  sectionTitle: { fontSize: 20, fontWeight: 'bold', marginBottom: 10, color: '#00BFFF' },
  bookingItem: { padding: 10, borderWidth: 1, borderColor: '#00BFFF', borderRadius: 10, marginBottom: 10, backgroundColor: '#fff' },
  bookingHotel: { fontSize: 16, fontWeight: 'bold', color: '#333' },
  bookingDates: { fontSize: 14, color: '#555' },
});

export default Profile;

