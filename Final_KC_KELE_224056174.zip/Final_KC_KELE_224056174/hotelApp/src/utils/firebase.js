import { initializeApp } from "firebase/app";
import { getAuth } from "firebase/auth";
import { getFirestore } from "firebase/firestore";
import { getAnalytics } from "firebase/analytics";

const firebaseConfig = {
  apiKey: "AIzaSyBnO31QHZP9ObPg92Sb7BLAi-U9Avaa-gs",
  authDomain: "hotelapp-aa9c0.firebaseapp.com",
  projectId: "hotelapp-aa9c0",
  storageBucket: "hotelapp-aa9c0.appspot.com",
  messagingSenderId: "619376854089",
  appId: "1:619376854089:web:650f9873818010c053ab98",
  measurementId: "G-8QE6Q5Z0WY"
};

const app = initializeApp(firebaseConfig);
export const auth = getAuth(app);
export const db = getFirestore(app);
export const analytics = getAnalytics(app);
